package dev.matteomac81888.echo.extensions.builtin.lyrics

import dev.brahmkshatriya.echo.common.clients.LyricsSearchClient
import dev.brahmkshatriya.echo.common.helpers.ContinuationCallback.Companion.await
import dev.brahmkshatriya.echo.common.helpers.PagedData
import dev.brahmkshatriya.echo.common.models.ExtensionType
import dev.brahmkshatriya.echo.common.models.Feed
import dev.brahmkshatriya.echo.common.models.Feed.Companion.toFeed
import dev.brahmkshatriya.echo.common.models.ImageHolder.Companion.toResourceImageHolder
import dev.brahmkshatriya.echo.common.models.ImportType
import dev.brahmkshatriya.echo.common.models.Lyrics
import dev.brahmkshatriya.echo.common.models.Metadata
import dev.brahmkshatriya.echo.common.models.Track
import dev.brahmkshatriya.echo.common.settings.Setting
import dev.brahmkshatriya.echo.common.settings.Settings
import dev.matteomac81888.echo.BuildConfig
import dev.matteomac81888.echo.R
import dev.matteomac81888.echo.utils.Serializer.toData
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.Normalizer
import java.util.concurrent.TimeUnit
import java.util.logging.Level
import java.util.logging.Logger

class DefaultLyricsExtension : LyricsSearchClient {

    init { Logger.getLogger("org.jaudiotagger").level = Level.OFF }

    companion object {
        val metadata = Metadata(
            className = "DefaultLyricsExtension", path = "", importType = ImportType.BuiltIn,
            type = ExtensionType.LYRICS, id = "echo-default-lyrics", name = "Testi (Auto + Karaoke)",
            description = "Motore Supremo: Polling asincrono con Grace Period per Apple/Spotify/Mxm. Fallback istantaneo Lrclib/Deezer.",
            version = "v${BuildConfig.VERSION_CODE}", author = "Echo x Spicy",
            icon = R.drawable.ic_queue_music.toResourceImageHolder(), isEnabled = true
        )
    }

    private val httpClient = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(4, TimeUnit.SECONDS).build()

    private var appleToken: String? = null
    private var spotifyToken: String? = null
    private var mxmToken: String? = null
    private var deezerToken: String? = null
    private var deezerSessionId: String? = null

    private fun JsonElement?.safeObj(): JsonObject? = this as? JsonObject
    private fun JsonElement?.safeArray(): JsonArray? = this as? JsonArray
    private val JsonElement?.asString: String? get() = try { if (this is JsonNull) null else this?.jsonPrimitive?.contentOrNull } catch (e: Exception) { null }

    private suspend fun callWithRetry(request: Request, maxRetries: Int = 1, baseDelayMs: Long = 200L): Response? {
        var attempt = 0
        while (true) {
            try {
                val resp = httpClient.newCall(request).await()
                if ((resp.code == 429 || resp.code == 503) && attempt < maxRetries) {
                    resp.close(); delay(baseDelayMs); attempt++; continue
                }
                return resp
            } catch (e: Exception) {
                if (attempt >= maxRetries) return null
                delay(baseDelayMs); attempt++
            }
        }
    }

    private fun String.clean(): String {
        var s = this; var prev: String; var iter = 0
        do {
            prev = s
            s = s.replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(feat\\.?|ft\\.?|featuring)\\s+[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)\\s+(feat\\.?|ft\\.?|featuring)\\s+.+$"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(re-?master(ed)?)(\\s*\\d{4})?[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(deluxe|bonus track|expanded|anniversary|special edition)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(radio edit|single version|album version|extended mix|clean version|explicit version)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(official\\s*(music\\s*)?video|lyric video|visualizer|\\bhd\\b|\\bhq\\b)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(live(\\s+(at|in|from))?.*?|acoustic(\\s+version)?)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)\\s*-\\s*(re-?master(ed)?(\\s*\\d{4})?|live(\\s+(at|in|from))?.*|acoustic(\\s+version)?|radio edit|single version|deluxe.*)\\s*$"), "")
                .replace(Regex("\\s{2,}"), " ").trim()
            iter++
        } while (s != prev && s.isNotBlank() && iter < 3)
        return s.ifBlank { this.trim() }
    }

    private fun normalizeForMatch(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}"), "").lowercase().replace(Regex("[’'`´]"), "'").replace(Regex("[^a-z0-9]"), "").trim()
    private fun titleMatches(cTitle: String, qTitle: String): Boolean {
        if (cTitle.isBlank() || qTitle.isBlank()) return false
        return cTitle == qTitle || cTitle.contains(qTitle) || qTitle.contains(cTitle)
    }

    private fun parseEnhancedLrc(lrc: String): Lyrics.WordByWord? {
        val lines = mutableListOf<List<Lyrics.Item>>()
        val lineRegex = Regex("""\[(\d+):(\d+(?:\.\d+)?)\](.*)""")
        val wordRegex = Regex("""<(\d+):(\d+(?:\.\d+)?)>([^<]*)""")
        lrc.lines().forEach { lineStr ->
            val content = lineRegex.find(lineStr)?.groupValues?.get(3) ?: return@forEach
            val wordMatches = wordRegex.findAll(content).toList()
            if (wordMatches.isNotEmpty()) {
                val words = mutableListOf<Lyrics.Item>()
                for (i in wordMatches.indices) {
                    val wStartMs = (wordMatches[i].groupValues[1].toLong() * 60000 + wordMatches[i].groupValues[2].toDouble() * 1000).toLong()
                    val text = wordMatches[i].groupValues[3].trim()
                    val wEndMs = if (i + 1 < wordMatches.size) (wordMatches[i+1].groupValues[1].toLong() * 60000 + wordMatches[i+1].groupValues[2].toDouble() * 1000).toLong() else wStartMs + 1500L
                    if (text.isNotEmpty()) words.add(Lyrics.Item(text, wStartMs, wEndMs))
                }
                if (words.isNotEmpty()) lines.add(words)
            }
        }
        return if (lines.isNotEmpty() && lines.any { it.size > 1 }) Lyrics.WordByWord(lines) else null
    }

    private fun parseSimpleLrc(lrc: String): Lyrics.Timed? {
        if (!lrc.contains("[")) return null
        val items = mutableListOf<Lyrics.Item>()
        val regex = Regex("""\[(\d{1,3}):(\d{2})[:.](\d{2,3})\](.*)""")
        val lines = lrc.split("\n")
        for (i in lines.indices) {
            val m = regex.find(lines[i]) ?: continue
            val (min, sec, ms, text) = m.destructured
            val startMs = min.toLong() * 60000 + sec.toLong() * 1000 + ms.toLong() * (if (ms.length == 2) 10 else 1)
            var endMs = startMs + 4000
            for (j in i + 1 until lines.size) {
                val nm = regex.find(lines[j]) ?: continue
                endMs = nm.groupValues[1].toLong() * 60000 + nm.groupValues[2].toLong() * 1000 + nm.groupValues[3].toLong() * (if (nm.groupValues[3].length == 2) 10 else 1)
                break
            }
            items.add(Lyrics.Item(text.trim(), startMs, endMs))
        }
        return if (items.isNotEmpty()) Lyrics.Timed(items) else null
    }

    private fun parseAppleTtml(ttml: String): Lyrics.WordByWord? {
        val lines = mutableListOf<List<Lyrics.Item>>()
        Regex("<p([^>]*)>(.*?)</p>", RegexOption.DOT_MATCHES_ALL).findAll(ttml).forEach { pMatch ->
            val pBeginStr = Regex("""begin="([^"]+)"""").find(pMatch.groupValues[1])?.groupValues?.get(1)
            val pBegin = pBeginStr?.let { t -> if(t.endsWith("s")) (t.dropLast(1).toDouble()*1000).toLong() else 0L } ?: 0L
            val spanMatches = Regex("<span([^>]*)>(.*?)</span>", RegexOption.DOT_MATCHES_ALL).findAll(pMatch.groupValues[2])
            val words = mutableListOf<Lyrics.Item>()
            if (spanMatches.none()) {
                val text = pMatch.groupValues[2].replace(Regex("<[^>]+>"), "").trim()
                if (text.isNotEmpty()) words.add(Lyrics.Item(text, pBegin, pBegin + 5000L))
            } else {
                for (sMatch in spanMatches) {
                    val sBegin = Regex("""begin="([^"]+)"""").find(sMatch.groupValues[1])?.groupValues?.get(1)?.let { t -> if(t.endsWith("s")) (t.dropLast(1).toDouble()*1000).toLong() else 0L } ?: pBegin
                    val sEnd = Regex("""end="([^"]+)"""").find(sMatch.groupValues[1])?.groupValues?.get(1)?.let { t -> if(t.endsWith("s")) (t.dropLast(1).toDouble()*1000).toLong() else 0L } ?: (sBegin + 1500L)
                    val text = sMatch.groupValues[2].replace(Regex("<[^>]+>"), "").replace("&amp;", "&").replace("&apos;", "'").replace("&quot;", "\"").trim()
                    if (text.isNotEmpty()) words.add(Lyrics.Item(text, sBegin, sEnd))
                }
            }
            if (words.isNotEmpty()) lines.add(words)
        }
        return if (lines.isNotEmpty()) Lyrics.WordByWord(lines) else null
    }

    private suspend fun fetchLrclib(track: Track): Lyrics.Lyric? {
        try {
            val title = URLEncoder.encode(track.title.clean(), "UTF-8")
            val artist = URLEncoder.encode(track.artists.firstOrNull()?.name?.clean() ?: "", "UTF-8")
            val album = URLEncoder.encode(track.album?.title?.clean() ?: "", "UTF-8")
            val dur = track.duration?.let { it / 1000 } ?: 0L

            val getUrl = buildString { append("https://lrclib.net/api/get?track_name=$title&artist_name=$artist"); if (album.isNotBlank()) append("&album_name=$album"); if (dur > 0) append("&duration=$dur") }
            val getResp = callWithRetry(Request.Builder().url(getUrl).header("Lrclib-Client", "Echo v1.0").build())
            if (getResp != null && getResp.isSuccessful) {
                val json = getResp.body?.string()?.toData<JsonElement>()?.getOrNull()
                val synced = json?.safeObj()?.get("syncedLyrics")?.asString
                if (!synced.isNullOrBlank()) return parseEnhancedLrc(synced) ?: parseSimpleLrc(synced)
            }

            val searchUrl = "https://lrclib.net/api/search?track_name=$title&artist_name=$artist"
            val searchResp = callWithRetry(Request.Builder().url(searchUrl).header("Lrclib-Client", "Echo v1.0").build()) ?: return null
            val results = searchResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeArray() ?: return null
            val normTitle = normalizeForMatch(track.title.clean())
            for (item in results) {
                val obj = item.safeObj() ?: continue
                val itemTitle = normalizeForMatch((obj["trackName"]?.asString ?: "").clean())
                if (!titleMatches(itemTitle, normTitle)) continue
                val synced = obj["syncedLyrics"]?.asString
                if (!synced.isNullOrBlank()) return parseEnhancedLrc(synced) ?: parseSimpleLrc(synced)
            }
        } catch (e: Exception) {}
        return null
    }

    private suspend fun fetchDeezerLyrics(track: Track): Lyrics.Timed? {
        try {
            if (deezerToken == null) {
                val req = Request.Builder().url("https://www.deezer.com/ajax/gw-light.php?method=deezer.getUserData&api_version=1.0&api_token=").build()
                val resp = callWithRetry(req) ?: return null
                deezerSessionId = resp.headers("Set-Cookie").firstOrNull { it.startsWith("sid=") }?.substringBefore(";")
                deezerToken = resp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("results")?.safeObj()?.get("checkForm")?.asString
            }
            if (deezerToken == null || deezerSessionId == null) return null

            val title = track.title.clean()
            val artist = track.artists.firstOrNull()?.name?.clean() ?: ""
            val q = URLEncoder.encode("track:\"$title\" artist:\"$artist\"", "UTF-8")
            val searchReq = Request.Builder().url("https://api.deezer.com/search?q=$q").build()
            val searchResp = callWithRetry(searchReq) ?: return null
            val data = searchResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("data")?.safeArray() ?: return null

            val normTitle = normalizeForMatch(title)
            var trackId: String? = null
            for (item in data) {
                val obj = item.safeObj() ?: continue
                if (titleMatches(normalizeForMatch((obj["title"]?.asString ?: "").clean()), normTitle)) {
                    trackId = obj["id"]?.asString ?: obj["id"]?.jsonPrimitive?.longOrNull?.toString()
                    break
                }
            }
            if (trackId == null) return null

            val body = "{\"sng_id\":\"$trackId\"}".toRequestBody("application/json; charset=utf-8".toMediaType())
            val lyricsReq = Request.Builder().url("https://www.deezer.com/ajax/gw-light.php?method=song.getLyrics&api_version=1.0&api_token=$deezerToken").header("Cookie", deezerSessionId!!).post(body).build()
            val lyricsResp = callWithRetry(lyricsReq) ?: return null
            val syncJson = lyricsResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("results")?.safeObj()?.get("LYRICS_SYNC_JSON")?.safeArray() ?: return null

            val lines = mutableListOf<Lyrics.Item>()
            for (i in 0 until syncJson.size) {
                val lineObj = syncJson[i].safeObj() ?: continue
                val text = lineObj["line"]?.asString ?: continue
                if (text.isBlank()) continue
                val startMs = lineObj["milliseconds"]?.asString?.toLongOrNull() ?: 0L
                val nextStartMs = lineObj["duration"]?.asString?.toLongOrNull()?.let { startMs + it } ?: syncJson.getOrNull(i+1)?.safeObj()?.get("milliseconds")?.asString?.toLongOrNull() ?: (startMs + 5000L)
                lines.add(Lyrics.Item(text, startMs, nextStartMs))
            }
            return if (lines.isNotEmpty()) Lyrics.Timed(lines) else null
        } catch (e: Exception) { return null }
    }

    private suspend fun fetchSpotifyLyrics(track: Track): Lyrics.WordByWord? {
        try {
            if (spotifyToken == null) {
                val req = Request.Builder().url("https://open.spotify.com/get_access_token?reason=transport&productType=web_player").build()
                spotifyToken = callWithRetry(req)?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("accessToken")?.asString
            }
            val token = spotifyToken ?: return null
            val q = URLEncoder.encode("track:${track.title.clean()} artist:${track.artists.firstOrNull()?.name?.clean() ?: ""}", "UTF-8")
            val reqSearch = Request.Builder().url("https://api.spotify.com/v1/search?q=$q&type=track&limit=1").header("Authorization", "Bearer $token").build()
            val respSearch = callWithRetry(reqSearch) ?: return null
            val trackId = respSearch.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("tracks")?.safeObj()?.get("items")?.safeArray()?.firstOrNull()?.safeObj()?.get("id")?.asString ?: return null

            val reqLyrics = Request.Builder().url("https://spclient.wg.spotify.com/color-lyrics/v2/track/$trackId?format=json&vocalRemoval=false").header("Authorization", "Bearer $token").header("App-Platform", "WebPlayer").build()
            val respLyrics = callWithRetry(reqLyrics) ?: return null
            val lyricsObj = respLyrics.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("lyrics")?.safeObj() ?: return null

            val linesArray = lyricsObj["lines"]?.safeArray() ?: return null
            val lines = mutableListOf<List<Lyrics.Item>>()

            for (lineEl in linesArray) {
                val lineObj = lineEl.safeObj() ?: continue
                val startTimeMs = lineObj["startTimeMs"]?.asString?.toLongOrNull() ?: continue
                val wordsArray = lineObj["syllables"]?.safeArray()

                if (wordsArray != null && wordsArray.isNotEmpty()) {
                    val words = mutableListOf<Lyrics.Item>()
                    for (i in 0 until wordsArray.size) {
                        val wordObj = wordsArray[i].safeObj() ?: continue
                        val text = wordObj["syllable"]?.asString ?: continue
                        if (text.isBlank()) continue
                        val start = wordObj["startTimeMs"]?.asString?.toLongOrNull() ?: startTimeMs
                        val nextStart = wordsArray.getOrNull(i + 1)?.safeObj()?.get("startTimeMs")?.asString?.toLongOrNull() ?: (start + 500L)
                        words.add(Lyrics.Item(text, start, nextStart))
                    }
                    if (words.isNotEmpty()) lines.add(words)
                }
            }
            return if (lines.isNotEmpty() && lines.any { it.size > 1 }) Lyrics.WordByWord(lines) else null
        } catch (e: Exception) { return null }
    }

    private suspend fun fetchAppleMusicLyrics(track: Track): Lyrics.WordByWord? = coroutineScope {
        try {
            if (appleToken == null) {
                val req = Request.Builder().url("https://music.apple.com/us/search").header("Accept", "text/html").build()
                val html = callWithRetry(req)?.body?.string() ?: return@coroutineScope null
                val match = Regex("name=\"desktop-music-app/config/environment\" content=\"([^\"]+)\"").find(html)
                if (match != null) appleToken = Regex("\"token\":\"([^\"]+)\"").find(URLDecoder.decode(match.groupValues[1], "UTF-8"))?.groupValues?.get(1)
            }
            val token = appleToken ?: return@coroutineScope null
            val cleanTitle = track.title.clean()
            val q = URLEncoder.encode("$cleanTitle ${track.artists.firstOrNull()?.name?.clean() ?: ""}".trim(), "UTF-8")

            val reqSearch = Request.Builder().url("https://itunes.apple.com/search?term=$q&entity=song&limit=3").build()
            val respSearch = callWithRetry(reqSearch) ?: return@coroutineScope null
            val results = respSearch.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("results")?.safeArray() ?: return@coroutineScope null

            val normTitle = normalizeForMatch(cleanTitle)
            val stores = mapOf("USA" to "us", "GBR" to "gb", "ITA" to "it", "FRA" to "fr", "ESP" to "es", "JPN" to "jp")

            val validSongs = results.mapNotNull { item ->
                val obj = item.safeObj() ?: return@mapNotNull null
                val trackName = normalizeForMatch((obj["trackName"]?.asString ?: "").clean())
                if (!trackName.contains(normTitle) && !normTitle.contains(trackName)) return@mapNotNull null
                val storefront = stores[obj["country"]?.asString ?: "USA"] ?: "us"
                val trackId = obj["trackId"]?.asString ?: return@mapNotNull null
                storefront to trackId
            }.distinct()

            if (validSongs.isEmpty()) return@coroutineScope null

            for ((storefront, songId) in validSongs) {
                val lyrReq = Request.Builder().url("https://amp-api.music.apple.com/v1/catalog/$storefront/songs/$songId/lyrics").header("Authorization", "Bearer $token").header("Origin", "https://music.apple.com").build()
                val lyrResp = callWithRetry(lyrReq) ?: continue
                val ttml = lyrResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("data")?.safeArray()?.firstOrNull()?.safeObj()?.get("attributes")?.safeObj()?.get("ttml")?.asString ?: continue
                val parsed = parseAppleTtml(ttml)
                if (parsed != null && parsed.list.any { it.size > 1 }) return@coroutineScope parsed
            }
        } catch (e: Exception) {}
        return@coroutineScope null
    }

    private suspend fun fetchMusixmatchLyrics(track: Track): Lyrics.WordByWord? {
        try {
            if (mxmToken == null) {
                val req = Request.Builder().url("https://apic-desktop.musixmatch.com/ws/1.1/token.get?app_id=web-desktop-app-v1.0&format=json").header("Cookie", "x-mxm-token-guid=").build()
                mxmToken = callWithRetry(req)?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("user_token")?.asString
            }
            val token = mxmToken ?: return null
            val cleanTitle = track.title.clean()
            val searchQ = URLEncoder.encode("$cleanTitle ${track.artists.firstOrNull()?.name?.clean() ?: ""}".trim(), "UTF-8")
            val searchUrl = "https://apic-desktop.musixmatch.com/ws/1.1/track.search?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&q=$searchQ&f_has_lyrics=1&page_size=3&s_track_rating=desc"
            val searchResp = callWithRetry(Request.Builder().url(searchUrl).build())
            val trackList = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("track_list")?.safeArray() ?: return null

            val normTitle = normalizeForMatch(cleanTitle)

            for (entry in trackList) {
                val t = entry.safeObj()?.get("track")?.safeObj() ?: continue
                val id = t["track_id"]?.asString ?: continue
                if (t["has_richsync"]?.asString != "1") continue
                if (!titleMatches(normalizeForMatch((t["track_name"]?.asString ?: "").clean()), normTitle)) continue

                val richReq = Request.Builder().url("https://apic-desktop.musixmatch.com/ws/1.1/track.richsync.get?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&track_id=$id").build()
                val richResp = callWithRetry(richReq) ?: continue
                val bodyStr = richResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("richsync")?.safeObj()?.get("richsync_body")?.asString ?: continue
                val array = bodyStr.toData<JsonArray>().getOrNull() ?: continue

                val lines = mutableListOf<List<Lyrics.Item>>()
                for (el in array) {
                    val obj = el.safeObj() ?: continue
                    val tsMs = ((obj["ts"]?.asString?.toDoubleOrNull() ?: continue) * 1000).toLong()
                    val teMs = ((obj["te"]?.asString?.toDoubleOrNull() ?: (tsMs / 1000.0 + 4.0)) * 1000).toLong()
                    val chars = obj["l"]?.safeArray() ?: continue
                    val words = mutableListOf<Lyrics.Item>()
                    for (i in 0 until chars.size) {
                        val charEl = chars[i].safeObj() ?: continue
                        val c = charEl["c"]?.asString ?: ""
                        if (c.isBlank()) continue
                        val offsetMs = ((charEl["o"]?.asString?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
                        val absStart = tsMs + offsetMs
                        val nextOffsetMs = if (i + 1 < chars.size) ((chars[i + 1].safeObj()?.get("o")?.asString?.toDoubleOrNull() ?: 0.0) * 1000).toLong() else (teMs - tsMs)
                        words.add(Lyrics.Item(c.trim(), absStart, minOf(tsMs + nextOffsetMs, teMs)))
                    }
                    if (words.isNotEmpty()) lines.add(words)
                }
                if (lines.isNotEmpty() && lines.any { it.size > 1 }) return Lyrics.WordByWord(lines)
            }
        } catch (e: Exception) {}
        return null
    }

    // =========================================================================================
    // SCORE & SMART WAIT (POLLING)
    // =========================================================================================

    private fun scoreLyrics(lyrics: Lyrics.Lyric?): Int {
        if (lyrics == null) return -1
        if (lyrics is Lyrics.WordByWord) {
            val multiWordLines = lyrics.list.count { it.size > 1 }
            return (multiWordLines * 15) + 50
        }
        if (lyrics is Lyrics.Timed) return lyrics.list.size
        return 0
    }

    /**
     * Smart Polling: Lancia le richieste in modo asincrono.
     * Monitora costantemente per un massimo di 2.5s.
     * Se una delle richieste restituisce un Karaoke valido (score > 30), ritorna istantaneamente.
     * Altrimenti, scaduti i 2.5s, restituisce il primo testo riga per riga trovato.
     */
    private suspend fun fetchBestLyrics(track: Track): Lyrics.Lyric? = coroutineScope {
        val appleDef = async { fetchAppleMusicLyrics(track) }
        val spotifyDef = async { fetchSpotifyLyrics(track) }
        val mxmDef = async { fetchMusixmatchLyrics(track) }
        val lrclibDef = async { fetchLrclib(track) }
        val deezerDef = async { fetchDeezerLyrics(track) }

        val wbwJobs = listOf(appleDef, spotifyDef, mxmDef)
        var fallbackTimed: Lyrics.Timed? = null

        val startTime = System.currentTimeMillis()

        // Polling loop per max 2500 millisecondi (2.5 secondi)
        while (System.currentTimeMillis() - startTime < 2500L) {
            // Cerca se qualche job WordByWord è finito con successo
            val completedWbw = wbwJobs.filter { it.isCompleted && !it.isCancelled }.mapNotNull { it.getCompleted() }
            if (completedWbw.isNotEmpty()) {
                val best = completedWbw.maxByOrNull { scoreLyrics(it) }
                if (best != null && scoreLyrics(best) >= 30) {
                    return@coroutineScope best // FAST EXIT! Karaoke trovato, usciamo subito.
                }
            }

            // Aggiorna il fallback (testo classico) man mano che le API veloci finiscono
            if (fallbackTimed == null) {
                if (lrclibDef.isCompleted) fallbackTimed = lrclibDef.getCompleted() as? Lyrics.Timed
                else if (deezerDef.isCompleted) fallbackTimed = deezerDef.getCompleted()
            }

            // Se TUTTE le API hanno fallito o hanno finito prima dei 2.5s, interrompiamo l'attesa
            if (wbwJobs.all { it.isCompleted }) break

            delay(100) // Aspetta 100ms e riprova
        }

        // Se nei 2.5 secondi non abbiamo trovato il Karaoke, restituiamo il testo normale se esiste
        if (fallbackTimed != null) return@coroutineScope fallbackTimed

        // Ultima spiaggia: aspetta che finiscano almeno LRCLIB o Deezer (nel raro caso siano stati lentissimi)
        return@coroutineScope lrclibDef.await() as? Lyrics.Timed ?: deezerDef.await()
    }

    override suspend fun searchTrackLyrics(clientId: String, track: Track): Feed<Lyrics> {
        // 1. Prova Metadati Locali
        val path = track.streamables.firstOrNull()?.id
        if (path != null && path.startsWith("/")) {
            try {
                val tag = AudioFileIO.read(File(path)).tag
                val text = tag?.getFirst(FieldKey.LYRICS)?.ifBlank { tag.getFirst("USLT") }
                if (!text.isNullOrBlank()) {
                    val parsed = parseSimpleLrc(text) ?: Lyrics.Simple(text)
                    return PagedData.Single { listOf(Lyrics("local_${track.id}", track.title, "Metadata Locali", parsed)) }.toFeed()
                }
            } catch (e: Exception) {}
        }

        // 2. Smart Engine (Ricerca Parallela + Polling per Karaoke)
        fetchBestLyrics(track)?.let {
            val typeDesc = if (it is Lyrics.WordByWord) "Karaoke" else "Sincronizzato"
            val lyrics = Lyrics(id = "best_${track.id}", track.title, "Spicy Engine ($typeDesc)", it)
            return PagedData.Single { listOf(lyrics) }.toFeed()
        }

        return PagedData.empty<Lyrics>().toFeed()
    }

    override suspend fun searchLyrics(query: String): Feed<Lyrics> {
        val q = URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://lrclib.net/api/search?q=$q"
        return try {
            val resp = callWithRetry(Request.Builder().url(searchUrl).build()) ?: return PagedData.empty<Lyrics>().toFeed()
            val results = resp.body?.string()?.toData<JsonArray>()?.getOrNull() ?: return PagedData.empty<Lyrics>().toFeed()
            PagedData.Single {
                results.mapNotNull { item ->
                    val obj = item.safeObj() ?: return@mapNotNull null
                    val rawLyrics = obj["syncedLyrics"]?.asString ?: obj["plainLyrics"]?.asString ?: return@mapNotNull null
                    Lyrics(
                        id = obj["id"]?.asString ?: return@mapNotNull null,
                        title = obj["trackName"]?.asString ?: "Unknown",
                        subtitle = obj["artistName"]?.asString ?: "Unknown",
                        lyrics = parseEnhancedLrc(rawLyrics) ?: parseSimpleLrc(rawLyrics) ?: Lyrics.Simple(rawLyrics)
                    )
                }
            }.toFeed()
        } catch (e: Exception) { PagedData.empty<Lyrics>().toFeed() }
    }

    override suspend fun loadLyrics(lyrics: Lyrics): Lyrics = lyrics
    override suspend fun getSettingItems(): List<Setting> = emptyList()
    override fun setSettings(settings: Settings) {}
}