package dev.matteomac81888.echo.ui.playlist.save

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import dev.brahmkshatriya.echo.common.models.EchoMediaItem
import dev.matteomac81888.echo.databinding.ItemShelfMediaBinding
import dev.matteomac81888.echo.ui.common.GridAdapter
import dev.matteomac81888.echo.ui.feed.viewholders.MediaViewHolder.Companion.bind
import dev.matteomac81888.echo.utils.ui.scrolling.ScrollAnimListAdapter
import dev.matteomac81888.echo.utils.ui.scrolling.ScrollAnimViewHolder

class MediaItemAdapter(
    private val listener: Listener,
) : ScrollAnimListAdapter<MediaItemAdapter.Item, MediaItemAdapter.ViewHolder>(
    DiffCallback
), GridAdapter {

    data class Item(val extensionId: String, val item: EchoMediaItem) {
        val id = extensionId + item.id
    }

    object DiffCallback : DiffUtil.ItemCallback<Item>() {
        override fun areItemsTheSame(oldItem: Item, newItem: Item) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Item, newItem: Item) = oldItem == newItem
    }

    fun interface Listener {
        fun onMediaItemClicked(view: View?, item: Item?)
    }

    class ViewHolder(
        parent: ViewGroup,
        private val listener: Listener,
        val binding: ItemShelfMediaBinding = ItemShelfMediaBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
    ) : ScrollAnimViewHolder(binding.root) {
        var item: Item? = null

        init {
            binding.coverContainer.cover.clipToOutline = true
            binding.root.setOnClickListener {
                listener.onMediaItemClicked(it, item)
            }
            binding.more.isVisible = false
        }

        fun bind(item: Item) {
            this.item = item
            binding.bind(item.item)
            binding.play.isVisible = false
        }
    }

    override val adapter = this
    override fun getSpanSize(position: Int, width: Int, count: Int) = count
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(parent, listener)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        super.onBindViewHolder(holder, position)
        val item = getItem(position) ?: return
        holder.bind(item)
    }
}