package dev.matteomac81888.echo.utils.ui.scrolling

import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import dev.matteomac81888.echo.utils.ui.AnimationUtils.applyTranslationYAnimation

abstract class ScrollAnimListAdapter<T : Any, VH : ScrollAnimViewHolder>(
    diffCallback: DiffUtil.ItemCallback<T>
) : ListAdapter<T, VH>(diffCallback) {

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.itemView.applyTranslationYAnimation(scrollY)
    }

    var recyclerView: RecyclerView? = null
    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        this.recyclerView = recyclerView
        recyclerView.addOnScrollListener(scrollListener)
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        recyclerView.removeOnScrollListener(scrollListener)
        this.recyclerView = null
    }

    var scrollY: Int = 0
    val scrollListener = object : RecyclerView.OnScrollListener() {
        override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
            scrollY = dy
            onEachViewHolder { scrollAmount = dy }
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun onEachViewHolder(action: VH.() -> Unit) {
        recyclerView?.let { rv ->
            for (i in 0 until rv.childCount) {
                val holder = rv.getChildViewHolder(rv.getChildAt(i)) as? VH
                if (holder?.bindingAdapter == this) holder.action()
            }
        }
    }
}