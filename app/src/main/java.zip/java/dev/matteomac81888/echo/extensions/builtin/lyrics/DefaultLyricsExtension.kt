// START OF FILE main/java/dev/matteomac81888/echo/extensions/builtin/lyrics/DefaultLyricsExtension.kt
package dev.matteomac81888.echo.extensions.builtin.lyrics

import dev.brahmkshatriya.echo.common.clients.LyricsSearchClient
import dev.brahmkshatriya.echo.common.helpers.ContinuationCallback.Companion.await
import dev.brahmkshatriya.echo.common.helpers.PagedData
import dev.brahmkshatriya.echo.common.models.ExtensionType
import dev.brahmkshatriya.echo.common.models.Feed
import dev.brahmkshatriya.echo.common.models.Feed.Companion.toFeed
import dev.brahmkshatriya.echo.common.models.ImageHolder.Companion.toResourceImageHolder
import dev.brahmkshatriya.echo.common.models.ImportType
import dev.brahmkshatriya.echo.common.models.Lyrics
import dev.brahmkshatriya.echo.common.models.Metadata
import dev.brahmkshatriya.echo.common.models.Track
import dev.brahmkshatriya.echo.common.settings.Setting
import dev.brahmkshatriya.echo.common.settings.Settings
import dev.matteomac81888.echo.BuildConfig
import dev.matteomac81888.echo.R
import dev.matteomac81888.echo.utils.Serializer.toData
import kotlinx.coroutines.async
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.Normalizer
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.logging.Level
import java.util.logging.Logger

class DefaultLyricsExtension : LyricsSearchClient {

    init { Logger.getLogger("org.jaudiotagger").level = Level.OFF }

    companion object {
        const val MIN_KARAOKE_SCORE = 30
        const val LINE_SYNC_TIMEOUT_MS = 4500L // Aumentato per dare tempo al Karaoke di caricarsi subito
        const val RICHSYNC_BACKGROUND_TIMEOUT_MS = 9000L

        val metadata = Metadata(
            className = "DefaultLyricsExtension", path = "", importType = ImportType.BuiltIn,
            type = ExtensionType.LYRICS, id = "echo-default-lyrics", name = "Testi (Auto + Karaoke)",
            description = "Motore Supremo: Integra Unison, BiniLyrics (Sillaba), Better Lyrics, Lrclib, Musixmatch, Apple Music e Spotify con matching rigoroso.",
            version = "v${BuildConfig.VERSION_CODE}", author = "Echo x Spicy",
            icon = R.drawable.ic_queue_music.toResourceImageHolder(), isEnabled = true
        )
    }

    private val httpClient = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(4, TimeUnit.SECONDS).build()

    private var appleToken: String? = null
    private var spotifyToken: String? = null
    private var mxmToken: String? = null
    private var mxmCookie: String? = null
    private var deezerToken: String? = null
    private var deezerSessionId: String? = null
    private var unisonKeyId: String? = null

    private val MXM_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private suspend fun ensureMxmToken(): String? {
        if (mxmToken != null && mxmCookie != null) return mxmToken
        val req = Request.Builder()
            .url("https://apic-desktop.musixmatch.com/ws/1.1/token.get?app_id=web-desktop-app-v1.0&format=json")
            .header("User-Agent", MXM_UA)
            .header("Cookie", "x-mxm-token-guid=")
            .build()
        val resp = callWithRetry(req) ?: return null
        mxmCookie = resp.headers("Set-Cookie").joinToString("; ") { it.substringBefore(";") }.ifBlank { null }
        mxmToken = resp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("user_token")?.asString
        return mxmToken
    }

    private fun getUnisonKeyId(): String {
        if (unisonKeyId != null) return unisonKeyId!!
        unisonKeyId = UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "")
        return unisonKeyId!!
    }

    private fun mxmRequest(url: String): Request {
        val builder = Request.Builder().url(url).header("User-Agent", MXM_UA)
        mxmCookie?.let { builder.header("Cookie", it) }
        return builder.build()
    }

    private fun JsonElement?.safeObj(): JsonObject? = this as? JsonObject
    private fun JsonElement?.safeArray(): JsonArray? = this as? JsonArray
    private val JsonElement?.asString: String? get() = try { if (this is JsonNull) null else this?.jsonPrimitive?.contentOrNull } catch (e: Exception) { null }

    private suspend fun callWithRetry(request: Request, maxRetries: Int = 1, baseDelayMs: Long = 200L): Response? {
        var attempt = 0
        while (true) {
            try {
                val resp = httpClient.newCall(request).await()
                if ((resp.code == 429 || resp.code == 503) && attempt < maxRetries) {
                    resp.close(); delay(baseDelayMs); attempt++; continue
                }
                return resp
            } catch (e: Exception) {
                if (attempt >= maxRetries) return null
                delay(baseDelayMs); attempt++
            }
        }
    }

    private fun String.clean(): String {
        var s = this; var prev: String; var iter = 0
        do {
            prev = s
            s = s.replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(feat\\.?|ft\\.?|featuring)\\s+[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)\\s+(feat\\.?|ft\\.?|featuring)\\s+.+$"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(re-?master(ed)?)(\\s*\\d{4})?[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(deluxe|bonus track|expanded|anniversary|special edition)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(radio edit|single version|album version|extended mix|clean version|explicit version)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(official\\s*(music\\s*)?video|lyric video|visualizer|\\bhd\\b|\\bhq\\b)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)[\\(\\[][^\\)\\]]*?(live(\\s+(at|in|from))?.*?|acoustic(\\s+version)?)[^\\)\\]]*?[\\)\\]]"), "")
                .replace(Regex("(?i)\\s*-\\s*(re-?master(ed)?(\\s*\\d{4})?|live(\\s+(at|in|from))?.*|acoustic(\\s+version)?|radio edit|single version|deluxe.*)\\s*$"), "")
                .replace(Regex("\\s{2,}"), " ").trim()
            iter++
        } while (s != prev && s.isNotBlank() && iter < 3)
        return s.ifBlank { this.trim() }
    }

    private fun getSearchableString(s: String): String {
        return Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}"), "") // Rimuove accenti
            .replace(Regex("[^a-zA-Z0-9]"), " ") // Mantiene solo alfanumerici
            .lowercase()
            .replace(Regex("\\s+"), " ") // Rimuove spazi doppi
            .trim()
    }

    /**
     * Algoritmo di matching infallibile: Evita i falsi positivi incrociando parole chiave.
     */
    private fun isStrictMatch(candidateTitle: String, candidateArtist: String, queryTitle: String, queryArtist: String): Boolean {
        val candT = getSearchableString(candidateTitle.clean())
        val queryT = getSearchableString(queryTitle.clean())

        if (candT.isBlank() || queryT.isBlank()) return false

        // Il titolo deve essere quasi identico o contenuto
        var tMatch = candT == queryT ||
                (candT.contains(queryT) && candT.length - queryT.length < 6) ||
                (queryT.contains(candT) && queryT.length - candT.length < 6)

        if (!tMatch) {
            val cWords = candT.split(" ")
            val qWords = queryT.split(" ")
            val overlap = cWords.intersect(qWords.toSet()).size
            val maxLen = maxOf(cWords.size, qWords.size)
            if (maxLen > 0 && (overlap.toFloat() / maxLen) >= 0.70f) {
                tMatch = true
            }
        }

        if (!tMatch) return false

        val candA = getSearchableString(candidateArtist.clean())
        val queryA = getSearchableString(queryArtist.clean())

        if (candA.isBlank() || queryA.isBlank()) return true

        val cAWords = candA.split(" ").filter { it.length > 2 }
        val qAWords = queryA.split(" ").filter { it.length > 2 }

        if (cAWords.isEmpty() || qAWords.isEmpty()) {
            return candA.contains(queryA) || queryA.contains(candA)
        }

        return cAWords.any { qAWords.contains(it) } || qAWords.any { cAWords.contains(it) }
    }

    private fun parseEnhancedLrc(lrc: String): Lyrics.WordByWord? {
        val lines = mutableListOf<List<Lyrics.Item>>()
        val lineRegex = Regex("""\[(\d+):(\d+(?:\.\d+)?)\](.*)""")
        val wordRegex = Regex("""<(\d+):(\d+(?:\.\d+)?)>([^<]*)""")
        lrc.lines().forEach { lineStr ->
            val content = lineRegex.find(lineStr)?.groupValues?.get(3) ?: return@forEach
            val wordMatches = wordRegex.findAll(content).toList()
            if (wordMatches.isNotEmpty()) {
                val words = mutableListOf<Lyrics.Item>()
                for (i in wordMatches.indices) {
                    val wStartMs = (wordMatches[i].groupValues[1].toLong() * 60000 + wordMatches[i].groupValues[2].toDouble() * 1000).toLong()
                    val text = wordMatches[i].groupValues[3].trim()
                    val wEndMs = if (i + 1 < wordMatches.size) (wordMatches[i+1].groupValues[1].toLong() * 60000 + wordMatches[i+1].groupValues[2].toDouble() * 1000).toLong() else wStartMs + 1500L
                    if (text.isNotEmpty()) words.add(Lyrics.Item(text, wStartMs, wEndMs))
                }
                if (words.isNotEmpty()) lines.add(words)
            }
        }
        return if (lines.isNotEmpty() && lines.any { it.size > 1 }) Lyrics.WordByWord(lines) else null
    }

    private fun parseSimpleLrc(lrc: String): Lyrics.Timed? {
        if (!lrc.contains("[")) return null
        val items = mutableListOf<Lyrics.Item>()
        val regex = Regex("""\[(\d{1,3}):(\d{2})[:.](\d{2,3})\](.*)""")
        val lines = lrc.split("\n")
        for (i in lines.indices) {
            val m = regex.find(lines[i]) ?: continue
            val (min, sec, ms, text) = m.destructured
            val startMs = min.toLong() * 60000 + sec.toLong() * 1000 + ms.toLong() * (if (ms.length == 2) 10 else 1)
            var endMs = startMs + 4000
            for (j in i + 1 until lines.size) {
                val nm = regex.find(lines[j]) ?: continue
                endMs = nm.groupValues[1].toLong() * 60000 + nm.groupValues[2].toLong() * 1000 + nm.groupValues[3].toLong() * (if (nm.groupValues[3].length == 2) 10 else 1)
                break
            }
            items.add(Lyrics.Item(text.trim(), startMs, endMs))
        }
        return if (items.isNotEmpty()) Lyrics.Timed(items) else null
    }

    private fun parseTtml(ttml: String): Lyrics.WordByWord? {
        val cleanTtml = ttml.replace(Regex("""<(/?)[a-zA-Z0-9-]+:([a-zA-Z0-9-]+)"""), "<$1$2")

        val lines = mutableListOf<List<Lyrics.Item>>()
        val pRegex = Regex("<p([^>]*)>(.*?)</p>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val spanRegex = Regex("<span([^>]*)>(.*?)</span>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))

        fun parseTimeAttr(attrString: String, key: String): Long? {
            val match = Regex("""$key=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(attrString)?.groupValues?.get(1) ?: return null
            val offsetMatch = Regex("""^([\d.,]+)(h|m|s|ms)$""").find(match)
            if (offsetMatch != null) {
                val value = offsetMatch.groupValues[1].replace(",", ".").toDoubleOrNull() ?: 0.0
                return when(offsetMatch.groupValues[2]) {
                    "h" -> (value * 3600000).toLong()
                    "m" -> (value * 60000).toLong()
                    "s" -> (value * 1000).toLong()
                    "ms" -> value.toLong()
                    else -> 0L
                }
            }
            val parts = match.replace(Regex("[^0-9.:]"), "").split(":")
            return try {
                when (parts.size) {
                    1 -> (parts[0].toDouble() * 1000).toLong()
                    2 -> (parts[0].toLong() * 60000) + (parts[1].toDouble() * 1000).toLong()
                    3 -> (parts[0].toLong() * 3600000) + (parts[1].toLong() * 60000) + (parts[2].toDouble() * 1000).toLong()
                    else -> null
                }
            } catch(e: Exception) { null }
        }

        pRegex.findAll(cleanTtml).forEach { pMatch ->
            val pAttrs = pMatch.groupValues[1]
            val pContent = pMatch.groupValues[2]

            if (pAttrs.contains("role=\"x-bg\"")) return@forEach

            val pBegin = parseTimeAttr(pAttrs, "begin") ?: 0L
            val pEnd = parseTimeAttr(pAttrs, "end") ?: (pBegin + 5000L)

            val spanMatches = spanRegex.findAll(pContent).toList()
            val words = mutableListOf<Lyrics.Item>()

            if (spanMatches.isEmpty()) {
                val text = pContent.replace(Regex("<[^>]+>"), "").replace("&amp;", "&").replace("&apos;", "'").replace("&quot;", "\"").trim()
                if (text.isNotEmpty()) words.add(Lyrics.Item(text, pBegin, pEnd))
            } else {
                for (i in spanMatches.indices) {
                    val sMatch = spanMatches[i]
                    val sAttrs = sMatch.groupValues[1]
                    val sBegin = parseTimeAttr(sAttrs, "begin") ?: pBegin
                    var sEnd = parseTimeAttr(sAttrs, "end")

                    if (sEnd == null) {
                        sEnd = if (i + 1 < spanMatches.size) {
                            parseTimeAttr(spanMatches[i+1].groupValues[1], "begin") ?: pEnd
                        } else {
                            pEnd
                        }
                    }

                    val text = sMatch.groupValues[2].replace(Regex("<[^>]+>"), "").replace("&amp;", "&").replace("&apos;", "'").replace("&quot;", "\"").trim()
                    if (text.isNotEmpty()) words.add(Lyrics.Item(text, sBegin, sEnd))
                }
            }
            if (words.isNotEmpty()) lines.add(words)
        }
        return if (lines.isNotEmpty() && lines.any { it.size > 1 }) Lyrics.WordByWord(lines) else null
    }

    private suspend fun fetchBiniLyrics(track: Track): Lyrics.WordByWord? {
        try {
            val title = URLEncoder.encode(track.title.clean(), "UTF-8")
            val artist = URLEncoder.encode(track.artists.firstOrNull()?.name?.clean() ?: "", "UTF-8")
            val url = "https://lyrics-api.binimum.org/lyrics?song=$title&artist=$artist"
            val req = Request.Builder().url(url).build()
            val resp = callWithRetry(req) ?: return null
            val json = resp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj() ?: return null
            val ttml = json["lyrics"]?.asString ?: return null
            return parseTtml(ttml)
        } catch (e: Exception) {}
        return null
    }

    private suspend fun fetchUnisonLyrics(track: Track): Lyrics.Lyric? {
        try {
            val title = track.title.clean()
            val artist = track.artists.firstOrNull()?.name?.clean() ?: ""
            val videoId = URLEncoder.encode(track.id, "UTF-8")
            val tEnc = URLEncoder.encode(title, "UTF-8")
            val aEnc = URLEncoder.encode(artist, "UTF-8")
            val dur = track.duration?.let { it / 1000 } ?: 0L

            val url = "https://unison.boidu.dev/lyrics?v=$videoId&song=$tEnc&artist=$aEnc&duration=$dur"
            var req = Request.Builder().url(url).header("x-key-id", getUnisonKeyId()).build()
            var resp = callWithRetry(req)
            var json = resp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()

            if (json == null || json["success"]?.jsonPrimitive?.booleanOrNull != true) {
                val q = URLEncoder.encode("$title $artist".trim(), "UTF-8")
                val searchUrl = "https://unison.boidu.dev/lyrics/search?q=$q"
                val searchReq = Request.Builder().url(searchUrl).header("x-key-id", getUnisonKeyId()).build()
                val searchResp = callWithRetry(searchReq)
                val searchJson = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()
                val entries = searchJson?.get("data")?.safeArray()

                var lyricsId: Long? = null
                if (entries != null) {
                    for (item in entries) {
                        val obj = item.safeObj() ?: continue
                        val cTitle = obj["song"]?.asString ?: ""
                        val cArtist = obj["artist"]?.asString ?: ""
                        if (isStrictMatch(cTitle, cArtist, title, artist)) {
                            lyricsId = obj["id"]?.jsonPrimitive?.longOrNull
                            break
                        }
                    }
                }

                if (lyricsId != null) {
                    val idUrl = "https://unison.boidu.dev/lyrics/$lyricsId"
                    val idReq = Request.Builder().url(idUrl).header("x-key-id", getUnisonKeyId()).build()
                    val idResp = callWithRetry(idReq)
                    json = idResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()
                }
            }

            if (json != null && json["success"]?.jsonPrimitive?.booleanOrNull == true) {
                val data = json["data"]?.safeObj() ?: return null
                val format = data["format"]?.asString
                val lyricsRaw = data["lyrics"]?.asString ?: return null

                return when (format) {
                    "ttml" -> parseTtml(lyricsRaw)
                    "lrc" -> parseEnhancedLrc(lyricsRaw) ?: parseSimpleLrc(lyricsRaw)
                    "plain" -> Lyrics.Simple(lyricsRaw)
                    else -> null
                }
            }
        } catch (e: Exception) {}
        return null
    }

    private suspend fun fetchMusixmatchLyrics(track: Track): Lyrics.WordByWord? {
        try {
            val token = ensureMxmToken() ?: return null
            val cleanTitle = track.title.clean()

            val titleEnc = URLEncoder.encode(cleanTitle, "UTF-8")
            val artistEnc = URLEncoder.encode(track.artists.firstOrNull()?.name?.clean() ?: "", "UTF-8")
            var searchUrl = "https://apic-desktop.musixmatch.com/ws/1.1/track.search?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&q_track=$titleEnc&q_artist=$artistEnc&f_has_lyrics=1&page_size=10&s_track_rating=desc"
            var searchResp = callWithRetry(mxmRequest(searchUrl))
            var trackList = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("track_list")?.safeArray()

            if (trackList.isNullOrEmpty()) {
                val searchQ = URLEncoder.encode("$cleanTitle ${track.artists.firstOrNull()?.name?.clean() ?: ""}".trim(), "UTF-8")
                searchUrl = "https://apic-desktop.musixmatch.com/ws/1.1/track.search?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&q=$searchQ&f_has_lyrics=1&page_size=10&s_track_rating=desc"
                searchResp = callWithRetry(mxmRequest(searchUrl))
                trackList = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("track_list")?.safeArray()
            }

            if (trackList.isNullOrEmpty()) return null

            for (entry in trackList) {
                val t = entry.safeObj()?.get("track")?.safeObj() ?: continue
                val id = t["track_id"]?.asString ?: continue
                if (t["has_richsync"]?.asString != "1") continue
                val cTitle = t["track_name"]?.asString ?: ""
                val cArtist = t["artist_name"]?.asString ?: ""

                if (!isStrictMatch(cTitle, cArtist, cleanTitle, track.artists.firstOrNull()?.name ?: "")) continue

                val richReq = mxmRequest("https://apic-desktop.musixmatch.com/ws/1.1/track.richsync.get?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&track_id=$id")
                val richResp = callWithRetry(richReq) ?: continue
                val bodyStr = richResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("richsync")?.safeObj()?.get("richsync_body")?.asString ?: continue

                val array = try {
                    dev.matteomac81888.echo.utils.Serializer.json.parseToJsonElement(bodyStr).jsonArray
                } catch (e: Exception) { null } ?: continue

                val lines = mutableListOf<List<Lyrics.Item>>()
                for (el in array) {
                    val obj = el.safeObj() ?: continue
                    val tsMs = ((obj["ts"]?.asString?.toDoubleOrNull() ?: continue) * 1000).toLong()
                    val teMs = ((obj["te"]?.asString?.toDoubleOrNull() ?: (tsMs / 1000.0 + 4.0)) * 1000).toLong()
                    val chars = obj["l"]?.safeArray() ?: continue
                    val words = mutableListOf<Lyrics.Item>()
                    for (i in 0 until chars.size) {
                        val charEl = chars[i].safeObj() ?: continue
                        val c = charEl["c"]?.asString ?: ""
                        if (c.isBlank()) continue
                        val offsetMs = ((charEl["o"]?.asString?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
                        val absStart = tsMs + offsetMs
                        val nextOffsetMs = if (i + 1 < chars.size) ((chars[i + 1].safeObj()?.get("o")?.asString?.toDoubleOrNull() ?: 0.0) * 1000).toLong() else (teMs - tsMs)
                        words.add(Lyrics.Item(c.trim(), absStart, minOf(tsMs + nextOffsetMs, teMs)))
                    }
                    if (words.isNotEmpty()) lines.add(words)
                }
                if (lines.isNotEmpty() && lines.any { it.size > 1 }) return Lyrics.WordByWord(lines)
            }
        } catch (e: Exception) {}
        return null
    }

    private suspend fun fetchMusixmatchSubtitleLyrics(track: Track): Lyrics.Timed? {
        try {
            val token = ensureMxmToken() ?: return null
            val cleanTitle = track.title.clean()
            val titleEnc = URLEncoder.encode(cleanTitle, "UTF-8")
            val artistEnc = URLEncoder.encode(track.artists.firstOrNull()?.name?.clean() ?: "", "UTF-8")

            var searchUrl = "https://apic-desktop.musixmatch.com/ws/1.1/track.search?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&q_track=$titleEnc&q_artist=$artistEnc&f_has_subtitle=1&page_size=10&s_track_rating=desc"
            var searchResp = callWithRetry(mxmRequest(searchUrl))
            var trackList = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("track_list")?.safeArray()

            if (trackList.isNullOrEmpty()) {
                val searchQ = URLEncoder.encode("$cleanTitle ${track.artists.firstOrNull()?.name?.clean() ?: ""}".trim(), "UTF-8")
                searchUrl = "https://apic-desktop.musixmatch.com/ws/1.1/track.search?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&q=$searchQ&f_has_subtitle=1&page_size=10&s_track_rating=desc"
                searchResp = callWithRetry(mxmRequest(searchUrl))
                trackList = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("track_list")?.safeArray()
            }
            if (trackList.isNullOrEmpty()) return null

            for (entry in trackList) {
                val t = entry.safeObj()?.get("track")?.safeObj() ?: continue
                val id = t["track_id"]?.asString ?: continue
                if (t["has_subtitles"]?.asString != "1") continue
                val cTitle = t["track_name"]?.asString ?: ""
                val cArtist = t["artist_name"]?.asString ?: ""

                if (!isStrictMatch(cTitle, cArtist, cleanTitle, track.artists.firstOrNull()?.name ?: "")) continue

                val subReq = mxmRequest("https://apic-desktop.musixmatch.com/ws/1.1/track.subtitle.get?app_id=web-desktop-app-v1.0&usertoken=$token&format=json&track_id=$id&subtitle_format=lrc")
                val subResp = callWithRetry(subReq) ?: continue
                val lrc = subResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("message")?.safeObj()?.get("body")?.safeObj()?.get("subtitle")?.safeObj()?.get("subtitle_body")?.asString ?: continue
                val parsed = parseSimpleLrc(lrc)
                if (parsed != null) return parsed
            }
        } catch (e: Exception) {}
        return null
    }

    private suspend fun fetchLrclib(track: Track): Lyrics.Lyric? {
        var bestPlain: String? = null
        try {
            val rawTitle = track.title.clean()
            val rawArtist = track.artists.firstOrNull()?.name?.clean() ?: ""
            val title = URLEncoder.encode(rawTitle, "UTF-8")
            val artist = URLEncoder.encode(rawArtist, "UTF-8")
            val album = URLEncoder.encode(track.album?.title?.clean() ?: "", "UTF-8")
            val dur = track.duration?.let { it / 1000 } ?: 0L

            val getUrl = buildString { append("https://lrclib.net/api/get?track_name=$title&artist_name=$artist"); if (album.isNotBlank()) append("&album_name=$album"); if (dur > 0) append("&duration=$dur") }
            val getResp = callWithRetry(Request.Builder().url(getUrl).header("Lrclib-Client", "Echo v1.0").build())
            if (getResp != null && getResp.isSuccessful) {
                val json = getResp.body?.string()?.toData<JsonElement>()?.getOrNull()
                val synced = json?.safeObj()?.get("syncedLyrics")?.asString
                if (!synced.isNullOrBlank()) return parseEnhancedLrc(synced) ?: parseSimpleLrc(synced)
                json?.safeObj()?.get("plainLyrics")?.asString?.takeIf { it.isNotBlank() }?.let { bestPlain = it }
            }

            val searchUrl = "https://lrclib.net/api/search?track_name=$title&artist_name=$artist"
            val searchResp = callWithRetry(Request.Builder().url(searchUrl).header("Lrclib-Client", "Echo v1.0").build())
            val results = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeArray()
            if (results != null) {
                for (item in results) {
                    val obj = item.safeObj() ?: continue
                    val cTitle = obj["trackName"]?.asString ?: ""
                    val cArtist = obj["artistName"]?.asString ?: ""
                    if (!isStrictMatch(cTitle, cArtist, rawTitle, rawArtist)) continue

                    val synced = obj["syncedLyrics"]?.asString
                    if (!synced.isNullOrBlank()) return parseEnhancedLrc(synced) ?: parseSimpleLrc(synced)
                    if (bestPlain == null) obj["plainLyrics"]?.asString?.takeIf { it.isNotBlank() }?.let { bestPlain = it }
                }
            }
        } catch (e: Exception) {}
        return bestPlain?.let { Lyrics.Simple(it) }
    }

    private suspend fun fetchDeezerLyrics(track: Track): Lyrics.Lyric? {
        try {
            if (deezerToken == null) {
                val req = Request.Builder().url("https://www.deezer.com/ajax/gw-light.php?method=deezer.getUserData&api_version=1.0&api_token=").build()
                val resp = callWithRetry(req) ?: return null
                deezerSessionId = resp.headers("Set-Cookie").firstOrNull { it.startsWith("sid=") }?.substringBefore(";")
                deezerToken = resp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("results")?.safeObj()?.get("checkForm")?.asString
            }
            if (deezerToken == null || deezerSessionId == null) return null

            val title = track.title.clean()
            val artist = track.artists.firstOrNull()?.name?.clean() ?: ""
            val q = URLEncoder.encode("track:\"$title\" artist:\"$artist\"", "UTF-8")
            val searchReq = Request.Builder().url("https://api.deezer.com/search?q=$q").build()
            val searchResp = callWithRetry(searchReq)
            var data = searchResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("data")?.safeArray()

            if (data.isNullOrEmpty()) {
                val looseQ = URLEncoder.encode("$title $artist".trim(), "UTF-8")
                val looseResp = callWithRetry(Request.Builder().url("https://api.deezer.com/search?q=$looseQ").build())
                data = looseResp?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("data")?.safeArray()
            }
            if (data.isNullOrEmpty()) return null

            var trackId: String? = null
            for (item in data) {
                val obj = item.safeObj() ?: continue
                val cTitle = obj["title"]?.asString ?: ""
                val cArtist = obj["artist"]?.safeObj()?.get("name")?.asString ?: ""

                if (isStrictMatch(cTitle, cArtist, title, artist)) {
                    trackId = obj["id"]?.asString ?: obj["id"]?.jsonPrimitive?.longOrNull?.toString()
                    break
                }
            }
            if (trackId == null) return null

            val body = "{\"sng_id\":\"$trackId\"}".toRequestBody("application/json; charset=utf-8".toMediaType())
            val lyricsReq = Request.Builder().url("https://www.deezer.com/ajax/gw-light.php?method=song.getLyrics&api_version=1.0&api_token=$deezerToken").header("Cookie", deezerSessionId!!).post(body).build()
            val lyricsResp = callWithRetry(lyricsReq) ?: return null
            val results = lyricsResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("results")?.safeObj() ?: return null
            val syncJson = results["LYRICS_SYNC_JSON"]?.safeArray()

            if (syncJson != null && syncJson.isNotEmpty()) {
                val lines = mutableListOf<Lyrics.Item>()
                for (i in 0 until syncJson.size) {
                    val lineObj = syncJson[i].safeObj() ?: continue
                    val text = lineObj["line"]?.asString ?: continue
                    if (text.isBlank()) continue
                    val startMs = lineObj["milliseconds"]?.asString?.toLongOrNull() ?: 0L
                    val nextStartMs = lineObj["duration"]?.asString?.toLongOrNull()?.let { startMs + it } ?: syncJson.getOrNull(i+1)?.safeObj()?.get("milliseconds")?.asString?.toLongOrNull() ?: (startMs + 5000L)
                    lines.add(Lyrics.Item(text, startMs, nextStartMs))
                }
                if (lines.isNotEmpty()) return Lyrics.Timed(lines)
            }

            val plain = results["LYRICS_TEXT"]?.asString
            if (!plain.isNullOrBlank()) return Lyrics.Simple(plain)
            return null
        } catch (e: Exception) { return null }
    }

    private suspend fun neteaseFindSongId(track: Track): String? {
        try {
            val title = track.title.clean()
            val artist = track.artists.firstOrNull()?.name?.clean() ?: ""
            val q = URLEncoder.encode("$title $artist".trim(), "UTF-8")
            val url = "https://music.163.com/api/search/get/web?csrf_token=&s=$q&type=1&offset=0&total=true&limit=10"
            val req = Request.Builder().url(url)
                .header("Referer", "https://music.163.com/")
                .header("User-Agent", "Mozilla/5.0")
                .build()
            val resp = callWithRetry(req) ?: return null
            val songs = resp.body?.string()?.toData<JsonElement>()?.getOrNull()
                ?.safeObj()?.get("result")?.safeObj()?.get("songs")?.safeArray() ?: return null
            if (songs.isEmpty()) return null

            for (item in songs) {
                val obj = item.safeObj() ?: continue
                val cTitle = obj["name"]?.asString ?: ""
                val cArtist = obj["artists"]?.safeArray()?.firstOrNull()?.safeObj()?.get("name")?.asString ?: ""
                if (!isStrictMatch(cTitle, cArtist, title, artist)) continue
                return obj["id"]?.asString ?: obj["id"]?.jsonPrimitive?.longOrNull?.toString()
            }
        } catch (e: Exception) {}
        return null
    }

    private suspend fun neteaseFetchLyricJson(songId: String): JsonObject? {
        return try {
            val url = "https://music.163.com/api/song/lyric?id=$songId&lv=1&kv=1&tv=-1&yv=1"
            val req = Request.Builder().url(url)
                .header("Referer", "https://music.163.com/")
                .header("User-Agent", "Mozilla/5.0")
                .build()
            val resp = callWithRetry(req) ?: return null
            resp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()
        } catch (e: Exception) { null }
    }

    private fun parseYrc(yrc: String): Lyrics.WordByWord? {
        val lines = mutableListOf<List<Lyrics.Item>>()
        val lineRegex = Regex("""^\[(\d+),(\d+)](.*)$""")
        val wordRegex = Regex("""\((\d+),(\d+),\d+\)([^(]*)""")
        yrc.lines().forEach { raw ->
            val m = lineRegex.find(raw.trim()) ?: return@forEach
            val content = m.groupValues[3]
            val words = mutableListOf<Lyrics.Item>()
            wordRegex.findAll(content).forEach { wm ->
                val start = wm.groupValues[1].toLongOrNull() ?: return@forEach
                val dur = wm.groupValues[2].toLongOrNull() ?: 0L
                val text = wm.groupValues[3].trim()
                if (text.isNotEmpty()) words.add(Lyrics.Item(text, start, start + dur))
            }
            if (words.isNotEmpty()) lines.add(words)
        }
        return if (lines.isNotEmpty() && lines.any { it.size > 1 }) Lyrics.WordByWord(lines) else null
    }

    private suspend fun fetchNeteaseLineLyrics(track: Track): Lyrics.Timed? {
        try {
            val id = neteaseFindSongId(track) ?: return null
            val json = neteaseFetchLyricJson(id) ?: return null
            val lrc = json["lrc"]?.safeObj()?.get("lyric")?.asString ?: return null
            return parseSimpleLrc(lrc)
        } catch (e: Exception) { return null }
    }

    private suspend fun fetchNeteaseWordByWordLyrics(track: Track): Lyrics.WordByWord? {
        try {
            val id = neteaseFindSongId(track) ?: return null
            val json = neteaseFetchLyricJson(id) ?: return null
            val yrc = json["yrc"]?.safeObj()?.get("lyric")?.asString ?: return null
            return parseYrc(yrc)
        } catch (e: Exception) { return null }
    }

    private suspend fun fetchSpotifyLyrics(track: Track): Lyrics.WordByWord? {
        try {
            if (spotifyToken == null) {
                val req = Request.Builder().url("https://open.spotify.com/get_access_token?reason=transport&productType=web_player").build()
                spotifyToken = callWithRetry(req)?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("accessToken")?.asString
            }
            val token = spotifyToken ?: return null
            val q = URLEncoder.encode("track:${track.title.clean()} artist:${track.artists.firstOrNull()?.name?.clean() ?: ""}", "UTF-8")
            val reqSearch = Request.Builder().url("https://api.spotify.com/v1/search?q=$q&type=track&limit=10").header("Authorization", "Bearer $token").build()
            val respSearch = callWithRetry(reqSearch) ?: return null

            val items = respSearch.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("tracks")?.safeObj()?.get("items")?.safeArray() ?: return null
            var trackId: String? = null
            for (item in items) {
                val obj = item.safeObj() ?: continue
                val cTitle = obj["name"]?.asString ?: ""
                val cArtist = obj["artists"]?.safeArray()?.firstOrNull()?.safeObj()?.get("name")?.asString ?: ""
                if (isStrictMatch(cTitle, cArtist, track.title, track.artists.firstOrNull()?.name ?: "")) {
                    trackId = obj["id"]?.asString
                    break
                }
            }
            if (trackId == null) return null

            val reqLyrics = Request.Builder().url("https://spclient.wg.spotify.com/color-lyrics/v2/track/$trackId?format=json&vocalRemoval=false").header("Authorization", "Bearer $token").header("App-Platform", "WebPlayer").build()
            val respLyrics = callWithRetry(reqLyrics) ?: return null
            val lyricsObj = respLyrics.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("lyrics")?.safeObj() ?: return null

            val linesArray = lyricsObj["lines"]?.safeArray() ?: return null
            val lines = mutableListOf<List<Lyrics.Item>>()

            for (lineEl in linesArray) {
                val lineObj = lineEl.safeObj() ?: continue
                val startTimeMs = lineObj["startTimeMs"]?.asString?.toLongOrNull() ?: continue
                val wordsArray = lineObj["syllables"]?.safeArray()

                if (wordsArray != null && wordsArray.isNotEmpty()) {
                    val words = mutableListOf<Lyrics.Item>()
                    for (i in 0 until wordsArray.size) {
                        val wordObj = wordsArray[i].safeObj() ?: continue
                        val text = wordObj["syllable"]?.asString ?: continue
                        if (text.isBlank()) continue
                        val start = wordObj["startTimeMs"]?.asString?.toLongOrNull() ?: startTimeMs
                        val nextStart = wordsArray.getOrNull(i + 1)?.safeObj()?.get("startTimeMs")?.asString?.toLongOrNull() ?: (start + 500L)
                        words.add(Lyrics.Item(text, start, nextStart))
                    }
                    if (words.isNotEmpty()) lines.add(words)
                }
            }
            return if (lines.isNotEmpty() && lines.any { it.size > 1 }) Lyrics.WordByWord(lines) else null
        } catch (e: Exception) { return null }
    }

    private suspend fun fetchAppleMusicLyrics(track: Track): Lyrics.WordByWord? = coroutineScope {
        try {
            if (appleToken == null) {
                val req = Request.Builder().url("https://music.apple.com/us/search").header("Accept", "text/html").build()
                val html = callWithRetry(req)?.body?.string() ?: return@coroutineScope null
                val match = Regex("name=\"desktop-music-app/config/environment\" content=\"([^\"]+)\"").find(html)
                if (match != null) appleToken = Regex("\"token\":\"([^\"]+)\"").find(URLDecoder.decode(match.groupValues[1], "UTF-8"))?.groupValues?.get(1)
            }
            val token = appleToken ?: return@coroutineScope null
            val cleanTitle = track.title.clean()
            val q = URLEncoder.encode("$cleanTitle ${track.artists.firstOrNull()?.name?.clean() ?: ""}".trim(), "UTF-8")

            val localeCountry = java.util.Locale.getDefault().country.takeIf { it.isNotBlank() } ?: "US"
            var reqSearch = Request.Builder().url("https://itunes.apple.com/search?term=$q&entity=song&limit=10&country=$localeCountry").build()
            var respSearch = callWithRetry(reqSearch)
            var results = respSearch?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("results")?.safeArray()

            if (results.isNullOrEmpty() && localeCountry != "US") {
                reqSearch = Request.Builder().url("https://itunes.apple.com/search?term=$q&entity=song&limit=10&country=US").build()
                respSearch = callWithRetry(reqSearch)
                results = respSearch?.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("results")?.safeArray()
            }

            if (results.isNullOrEmpty()) return@coroutineScope null

            val stores = mapOf("USA" to "us", "GBR" to "gb", "ITA" to "it", "FRA" to "fr", "ESP" to "es", "JPN" to "jp")

            val validSongs = results.mapNotNull { item ->
                val obj = item.safeObj() ?: return@mapNotNull null
                val cTitle = obj["trackName"]?.asString ?: ""
                val cArtist = obj["artistName"]?.asString ?: ""

                if (!isStrictMatch(cTitle, cArtist, cleanTitle, track.artists.firstOrNull()?.name ?: "")) return@mapNotNull null
                val country = obj["country"]?.asString ?: "US"
                val storefront = stores[country] ?: country.lowercase()
                val trackId = obj["trackId"]?.asString ?: return@mapNotNull null
                storefront to trackId
            }.distinct()

            if (validSongs.isEmpty()) return@coroutineScope null

            for ((storefront, songId) in validSongs) {
                val lyrReq = Request.Builder().url("https://amp-api.music.apple.com/v1/catalog/$storefront/songs/$songId/lyrics").header("Authorization", "Bearer $token").header("Origin", "https://music.apple.com").build()
                val lyrResp = callWithRetry(lyrReq) ?: continue
                val ttml = lyrResp.body?.string()?.toData<JsonElement>()?.getOrNull()?.safeObj()?.get("data")?.safeArray()?.firstOrNull()?.safeObj()?.get("attributes")?.safeObj()?.get("ttml")?.asString ?: continue
                val parsed = parseTtml(ttml)
                if (parsed != null && parsed.list.any { it.size > 1 }) return@coroutineScope parsed
            }
        } catch (e: Exception) {}
        return@coroutineScope null
    }

    private fun lineSyncQuality(lyrics: Lyrics.Lyric?): Int {
        if (lyrics == null) return -1
        return when (lyrics) {
            is Lyrics.WordByWord -> lyrics.list.size + 10_000
            is Lyrics.Timed -> lyrics.list.size
            is Lyrics.Simple -> if (lyrics.text.isNotBlank()) 1 else 0
            else -> 0
        }
    }

    /**
     * Recupera in parallelo TUTTE le fonti sincronizzate e karaoke in un SupervisorScope.
     */
    private suspend fun fetchAllLyricsConcurrent(track: Track, timeoutMs: Long): Lyrics.Lyric? = supervisorScope {
        val unisonDef = async { fetchUnisonLyrics(track) }
        val biniDef = async { fetchBiniLyrics(track) }
        val mxmRichDef = async { fetchMusixmatchLyrics(track) }
        val neteaseYrcDef = async { fetchNeteaseWordByWordLyrics(track) }
        val appleDef = async { fetchAppleMusicLyrics(track) }
        val spotifyDef = async { fetchSpotifyLyrics(track) }

        val lrclibDef = async { fetchLrclib(track) }
        val deezerDef = async { fetchDeezerLyrics(track) }
        val neteaseLrcDef = async { fetchNeteaseLineLyrics(track) }
        val mxmSubtitleDef = async { fetchMusixmatchSubtitleLyrics(track) }

        val jobs = listOf(unisonDef, biniDef, mxmRichDef, neteaseYrcDef, appleDef, spotifyDef, lrclibDef, deezerDef, neteaseLrcDef, mxmSubtitleDef)

        var bestResult: Lyrics.Lyric? = null
        val startTime = System.currentTimeMillis()

        while (System.currentTimeMillis() - startTime < timeoutMs) {
            val completed = jobs.filter { it.isCompleted && !it.isCancelled }
                .mapNotNull { runCatching { it.getCompleted() }.getOrNull() }

            if (completed.isNotEmpty()) {
                val candidate = completed.maxByOrNull { lineSyncQuality(it) }
                bestResult = candidate
                if (candidate is Lyrics.WordByWord && candidate.list.size > 5) {
                    break
                }
            }
            if (jobs.all { it.isCompleted }) break
            delay(100)
        }

        if (bestResult == null || lineSyncQuality(bestResult) < MIN_KARAOKE_SCORE) {
            val allResults = jobs.mapNotNull { runCatching { it.await() }.getOrNull() }
            bestResult = allResults.maxByOrNull { lineSyncQuality(it) } ?: bestResult
        }

        jobs.forEach { if (it.isActive) it.cancel() }
        bestResult
    }

    suspend fun searchRichSyncOnly(track: Track): Lyrics.WordByWord? =
        fetchAllLyricsConcurrent(track, RICHSYNC_BACKGROUND_TIMEOUT_MS) as? Lyrics.WordByWord

    override suspend fun searchTrackLyrics(clientId: String, track: Track): Feed<Lyrics> {
        val path = track.streamables.firstOrNull()?.id
        if (path != null && path.startsWith("/")) {
            try {
                val tag = AudioFileIO.read(File(path)).tag
                val text = tag?.getFirst(FieldKey.LYRICS)?.ifBlank { tag.getFirst("USLT") }
                if (!text.isNullOrBlank()) {
                    val parsed = parseSimpleLrc(text) ?: Lyrics.Simple(text)
                    return PagedData.Single { listOf(Lyrics("local_${track.id}", track.title, "Metadata Locali", parsed)) }.toFeed()
                }
            } catch (e: Exception) {}
        }

        fetchAllLyricsConcurrent(track, LINE_SYNC_TIMEOUT_MS)?.let {
            val typeDesc = if (it is Lyrics.WordByWord) "Karaoke" else "Sincronizzato"
            val lyrics = Lyrics(id = "best_${track.id}", track.title, "Spicy Engine ($typeDesc)", it)
            return PagedData.Single { listOf(lyrics) }.toFeed()
        }

        return PagedData.empty<Lyrics>().toFeed()
    }

    override suspend fun searchLyrics(query: String): Feed<Lyrics> {
        val q = URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://lrclib.net/api/search?q=$q"
        return try {
            val resp = callWithRetry(Request.Builder().url(searchUrl).build()) ?: return PagedData.empty<Lyrics>().toFeed()
            val results = resp.body?.string()?.toData<JsonArray>()?.getOrNull() ?: return PagedData.empty<Lyrics>().toFeed()
            PagedData.Single {
                results.mapNotNull { item ->
                    val obj = item.safeObj() ?: return@mapNotNull null
                    val rawLyrics = obj["syncedLyrics"]?.asString ?: obj["plainLyrics"]?.asString ?: return@mapNotNull null
                    Lyrics(
                        id = obj["id"]?.asString ?: return@mapNotNull null,
                        title = obj["trackName"]?.asString ?: "Unknown",
                        subtitle = obj["artistName"]?.asString ?: "Unknown",
                        lyrics = parseEnhancedLrc(rawLyrics) ?: parseSimpleLrc(rawLyrics) ?: Lyrics.Simple(rawLyrics)
                    )
                }
            }.toFeed()
        } catch (e: Exception) { PagedData.empty<Lyrics>().toFeed() }
    }

    override suspend fun loadLyrics(lyrics: Lyrics): Lyrics = lyrics
    override suspend fun getSettingItems(): List<Setting> = emptyList()
    override fun setSettings(settings: Settings) {}
}